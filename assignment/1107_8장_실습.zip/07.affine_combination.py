import numpy as np, cv2
import matplotlib.pyplot as plt

# 사용자 정의 affine 변환 함수
def affine_transform(image, aff_mat):
    h, w = image.shape[:2]
    transformed_image = np.zeros_like(image)  # 변환된 이미지 초기화

    # 역행렬 계산
    inv_aff_mat = np.linalg.inv(np.vstack([aff_mat, [0, 0, 1]]))[:2]

    for y in range(h):
        for x in range(w):
            # 새로운 좌표 계산
            src_pos = inv_aff_mat @ [x, y, 1]
            src_x, src_y = src_pos[:2]

            # 유효한 범위 안에 있을 때만 보간 적용
            if 0 <= src_x < w - 1 and 0 <= src_y < h - 1:
                x0, y0 = int(src_x), int(src_y)
                dx, dy = src_x - x0, src_y - y0

                # Bilinear interpolation
                value = (
                    (1 - dx) * (1 - dy) * image[y0, x0] +
                    dx * (1 - dy) * image[y0, x0 + 1] +
                    (1 - dx) * dy * image[y0 + 1, x0] +
                    dx * dy * image[y0 + 1, x0 + 1]
                )
                transformed_image[y, x] = value

    return transformed_image.astype(image.dtype)


def getAffineMat(center, degree, fx=1, fy=1, translate=(0,0)):      # 변환 행렬 합성 함수
    scale_mat = np.eye(3, dtype=np.float32)         # 크기 변경 행렬
    cen_trans = np.eye(3, dtype=np.float32)         # 중점 평행 이동
    org_trans = np.eye(3, dtype=np.float32)         # 원점 평행 이동
    trans_mat = np.eye(3, dtype=np.float32)         # 좌표 평행 이동
    rot_mat = np.eye(3, dtype=np.float32)           # 회전 변환 행렬

    radian = degree / 180 * np.pi
    rot_mat[0] = [ np.cos(radian), np.sin(radian), 0 ]  # 회전행렬 0행
    rot_mat[1] = [ -np.sin(radian), np.cos(radian), 0 ] # 회전행렬 1행

    cen_trans[:2, 2] = center                   # 중심 좌표 이동
    org_trans[:2, 2] = -center[0], -center[1]   # 원점으로 이동
    trans_mat[:2, 2] = translate                # 평행 이동 행렬의 원소 지정
    scale_mat[0, 0], scale_mat[1, 1] = fx, fy   # 크기 변경 행렬의 원소 지정

    ret_mat = cen_trans.dot(rot_mat.dot(trans_mat.dot(scale_mat.dot(org_trans))))
    # ret_mat = cen_trans.dot(rot_mat.dot(scale_mat.dot(trans_mat.dot(org_trans))))
    return np.delete(ret_mat, 2, axis=0)        # 마지막행 제거 ret_mat[0:2, :]

image = cv2.imread("/Users/kslivergun/work1/class/24-2-Digital-Image-Processing/ch08_기하학처리/img/affine2.jpg", cv2.IMREAD_GRAYSCALE)
if image is None: raise Exception("image error")

size = image.shape[::-1]        # 역순 정렬
center = np.divmod(size, 2)[0]  # 회전 중심 좌표
angle, tr = 45, (200, 0)        # 각도와 평행이동 값 지정

aff_mat1 = getAffineMat(center, angle)                  # 중심 좌표 기준 회전
aff_mat2 = getAffineMat((0, 0), 0, 2.0, 1.5)            # 크기 변경 - 확대
aff_mat3 = getAffineMat(center, angle, 0.7, 0.7)        # 회전 및 축소
aff_mat4 = getAffineMat(center, angle, 0.7, 0.7, tr)    # 복합 변환

dst1 = cv2.warpAffine(image, aff_mat1, size)    # openCV 함수
dst2 = cv2.warpAffine(image, aff_mat2, size)
dst3 = affine_transform(image, aff_mat3)        # 사용자 정의 함수
dst4 = affine_transform(image, aff_mat4)

cv2.imshow("image", image)
cv2.imshow("dst1_only_rotate", dst1)
cv2.imshow("dst2_only_scaling", dst2)
cv2.imshow("dst3_rotate_scaling", dst3)
cv2.imshow("dst4_rotate_scaling_translate", dst4)
cv2.waitKey(0)